"""""
#Exercise -1
#Question 1: Program to calculate an average in python
a={12,3,45,60,78,50,68}
avg=sum(a)/len(a)
print(avg)



#Question 2: Program to accept an integer value from a user in Python
#and to convert an input string value into an integer using an int() function.

input_string = input("Enter an integer: ")
integer_value = int(input_string)
# Print the integer value.
print("The integer value is:", integer_value)




#Question 3:Program to add two complex, float, and integer numbers
a1=5+4j
a2=55+47j
print("Complex of the integer:",a1+a2)
a3=5.5+4.7j
a4=6.6+7.0j
print("Complex of the float:",a3+a4)


#Question 4:Program to convert integer to float
n=int(input("Enter a value"))
print(float(n))


"""""
#Question 5:Program to perform addition of string and integer using explicit conversion
num_string = "10"
num_int = int(num_string)
num_sum = num_int + 25
print(num_sum)

