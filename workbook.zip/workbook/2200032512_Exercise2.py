"""
#Program 1:
n=int(input("Enter n value:"))
fact=1
for i in range(1,n+1):
    fact=fact*i
    print(fact)


#Program 2:
n=7
s=7
for i in range(1,n+1):
    print(n,"*",i,"=",n*i)


#program 3
# Accept the lengths of three sides of the triangle
side1 = float(input("Enter the length of side 1: "))
side2 = float(input("Enter the length of side 2: "))
side3 = float(input("Enter the length of side 3: "))
if side1**2 + side2**2 == side3**2 or side1**2 + side3**2 == side2**2 or side2**2 + side3**2 == side1**2:
    print("It is a right triangle.")
else:
    print("It is not a right triangle.")





#PROGRAM 4
n=int(input("Enter the range:"))
for i in range(0,n):
  for j in range(0,i+1):
     print("*",end=" ")
  print(" ")
for i in range(n-1,0,-1):
    for j in range(0,i):
        print("*", end=" ")
    print(" ")

"""
#PROGRAM 5

input_sequence = input("Enter a sequence of comma-separated 4-digit binary numbers: ")

# Split the input sequence into a list of binary numbers
binary_numbers = input_sequence.split(',')

# Initialize an empty list to store numbers divisible by 5
divisible_by_5 = []

# Iterate through each binary number in the list
for binary_number in binary_numbers:
    # Convert binary number to decimal
    decimal_number = int(binary_number, 2)

    # Check if the decimal number is divisible by 5
    if decimal_number % 5 == 0:
        divisible_by_5.append(binary_number)

# Print the result as a comma-separated sequence
print(','.join(divisible_by_5))
