'''
#program1
class MyClass:
  def __init__(self, name):
    self.name = name

  def display_name(self):
    print(self.name)

obj = MyClass("My Class")
obj.display_name()



#program 2
class Student:
    def __init__(self, student_id, student_name):
        self.student_id = student_id
        self.student_name = student_name

    def display_attributes(self):
        print("Attributes and Values:")
        print(f"Student ID: {self.student_id}")
        print(f"Student Name: {self.student_name}")
        print()

    def remove_attribute(self, attribute):
        delattr(self, attribute)

# Creating an instance of the Student class
student1 = Student(student_id=1, student_name="John Doe")

# Displaying attributes and their values
student1.display_attributes()

# Adding a new attribute student_class
student1.student_class = "10th Grade"

# Displaying updated attributes and their values
student1.display_attributes()

# Removing the student_name attribute
student1.remove_attribute("student_name")

# Displaying attributes after removal
student1.display_attributes()
'''


#3Q

class BankAccount:
    def __init__(self, accountNumber, name, balance):
        self.accountNumber = accountNumber
        self.name = name
        self.balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposit of {amount} successful. New balance: {self.balance}")
        else:
            print("Invalid deposit amount.")

    def withdrawal(self, amount):
        if amount > 0 and amount <= self.balance:
            self.balance -= amount
            print(f"Withdrawal of {amount} successful. New balance: {self.balance}")
        else:
            print("Invalid withdrawal amount or insufficient funds.")

    def bankFees(self):
        fees = self.balance * 0.05
        self.balance -= fees
        print(f"Bank fees of {fees} applied. New balance: {self.balance}")

    def display(self):
        print(f"Account Number: {self.accountNumber}")
        print(f"Account Owner: {self.name}")
        print(f"Balance: {self.balance}")

account1 = BankAccount(accountNumber=123456, name="John Doe", balance=1000)

account1.display()


account1.deposit(500)


account1.withdrawal(200)


account1.bankFees()


account1.display()
