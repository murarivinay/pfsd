'''
#Question 1
import random
import string

def colorr_hex():

    color_hex = "#{:06x}".format(random.randint(0, 0xFFFFFF))
    return color_hex

def alphabet(length):

    letters = string.ascii_letters
    return ''.join(random.choice(letters) for _ in range(length))

def valuee(min_val, max_val):
    # Generate a random value between two integers (inclusive)
    return random.randint(min_val, max_val)

def multiple_of_7():

    return random.randint(0, 10) * 7


h = colorr_hex()
a = alphabet(8)
v = valuee(5, 15)
m = multiple_of_7()

print("Random Color Hex:",h)
print("Random Alphabetical String:", a)
print("Random Value between 5 and 15:", v)
print("Random Multiple of 7 between 0 and 70:",m)







#question 2

import random
import pandas as pd

def excluding_six():
    return random.randrange(0, 6)

def excluding_ten():
    return random.randrange(5, 10)


def three():
    return random.randrange(0, 11, 3)

def date(start_date, end_date):
    return random.choice(pd.date_range(start_date, end_date))


start_date = '2023-01-01'
end_date = '2023-12-31'

print("Random integer between 0 and 6 (excluding 6):", excluding_six())
print("Random integer between 5 and 10 (excluding 10):", excluding_ten())
print("Random integer between 0 and 10, with a step of 3:", three())
print("Random Date between 2023-01-01 and 2023-12-31:", date(start_date, end_date))


'''

#Question 3

import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("students.csv")


df_below_20 = df[df['Age'] < 20]
df_20_to_25 = df[(df['Age'] >= 20) & (df['Age'] <= 25)]
df_above_25 = df[df['Age'] > 25]


below_20 = df_below_20['Grade'].mean()
grade_20to25 = df_20_to_25['Grade'].mean()
above_25 = df_above_25['Grade'].mean()


ages = ['Below 20', '20-25', 'Above 25']
avg_grades = [below_20, grade_20to25, above_25]

plt.bar(ages, avg_grades, color='red')
plt.xlabel('Age Groups')
plt.ylabel('Average Grade')
plt.title('Average Grade for Different Age Groups')
plt.show()